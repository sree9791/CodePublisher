#pragma once
/////////////////////////////////////////////////////////////////////
// PublishObjectFactory.h - Publish object factory                 //
// ver 1.0                                                         //
// Sreekar Reddy,Sykam , CSE687-OnLine Object Oriented Design, Sring 2019    //
/////////////////////////////////////////////////////////////////////
/*
*  Provides export and import declarations for Publisher
*
*  Required Files:
* -----------------
*  PublishObjectFactory.h, PublishObjectFactory.cpp 
* Ipublisher.h
*
*  Maintenance History:
* ----------------------
*  ver 1.0 : 09 Apr 2019
*  - first release
*/
#include "Ipublisher.h"

#ifdef IN_DLL
#define DLL_DECL __declspec(dllexport)
#else
#define DLL_DECL __declspec(dllimport)
#endif


// you can remove the | extern "C" | wrapper if you wish
extern "C" {
	// Instantiates CodePublisher* as Ipublisher*
	struct PublisherObjectFactory {
		// See PublisherObjectFactory.cpp for implementation
		DLL_DECL Ipublisher* dllcreate();
		Ipublisher* create();
	};
}

