/////////////////////////////////////////////////////////////////////////////
// Publisher.h - Which takes inputs of file path and patterns and publish  //
//                                 the matched files                       //
// ver 1.1                                                                 //
// ----------------------------------------------------------------------- //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * ==================
 * This Package provides class of the same name to publish the files which satifies the given regexes
 *
 * Required Files:
 * ===============
 *  Publisher.h
 *  Ipublisher.h
 *
 * Maintenance History:
 * ver 1.1 : 09 Apr 2019
 * - Implemented Interface design pattern so that, if we have to Implement Another language support can be done easily, 
       also to support with C++/CLI 
 * ver 1.0 : 05 Feb 2019
 * - first release
 */


#include<vector>
#include"Ipublisher.h"

class CodePublisher : public Ipublisher
{
public:
	~CodePublisher();
	void processInputs(int argc,char **argv);
	void startConverting();
	std::vector<std::string> getConvertedFiles();
	std::vector<std::string> getFilteredFiles();
	std::vector<std::string> publishFiles(int argc, char** argv);
private:
	std::vector<std::string> filteredFiles_;
	std::vector<std::string> convertedFiles_;
};

inline Ipublisher* Ipublisher::create()
{
	return new CodePublisher();
}
