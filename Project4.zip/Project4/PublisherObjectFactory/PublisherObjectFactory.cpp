#pragma once
/////////////////////////////////////////////////////////////////////
// PublisherObjectFactory.cpp - Publisher object factory           //
// ver 1.0                                                         //
// Sreekar Reddy, Sykam , CSE687-OnLine Object Oriented Design, Spring 2019//
/////////////////////////////////////////////////////////////////////

#include "PublisherObjectFactory.h"
#include<iostream>
#include "Publisher.h"

Ipublisher* PublisherObjectFactory::create()
{
	return new CodePublisher();
}