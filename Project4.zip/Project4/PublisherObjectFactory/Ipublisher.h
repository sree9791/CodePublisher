#pragma once

//////////////////////////////////////////////////////////////////////////		
// Ipublisher.h - interface for CodePublishing facility					//
// ver 1.0																//
// Sreekar Reddy,Sykam CSE687-OnLine Object Oriented Design, Spring 2019//
//////////////////////////////////////////////////////////////////////////

#include<string>
#include<vector>
class Ipublisher
{
public:
	static Ipublisher* create();
	virtual void processInputs(int argc, char** argv) = 0;
	virtual std::vector<std::string> publishFiles(int argc, char** argv) = 0;
	virtual void startConverting() = 0;
	virtual std::vector<std::string> getConvertedFiles() = 0;
	virtual std::vector<std::string> getFilteredFiles() = 0;
	virtual ~Ipublisher() {}
};

