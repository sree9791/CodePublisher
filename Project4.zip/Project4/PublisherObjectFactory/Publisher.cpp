#pragma once
/////////////////////////////////////////////////////////////////////////////
// Publisher.cpp - CodePublisher Functionality                             //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////

#include<string>
#include<iostream>
#include "../HTMLConverter/HTMLConverter.h"
#include "../Display/Display.h"
#include "../Loader/Loader.h"
#include "Ipublisher.h"
#include"Publisher.h"

#define IN_DLL

//-----> Destructor to Delete the memory allocated whenever it is not in use
CodePublisher::~CodePublisher()
{
	filteredFiles_.clear();
	convertedFiles_.clear();
}
//----> To load the files which are matched based on the patterns and regexes provide by the user
void CodePublisher::processInputs(int argc, char** argv)
{
	Loader load;
	load.loadFiles(argc, argv);
	filteredFiles_ = load.getLoadedFiles();
}
//-----> Start Converting the filtered Files into HTML Format
void CodePublisher::startConverting()
{
	HtmlConverter convert;
	convert.setFiles(filteredFiles_);
	convert.convertAllToHtml();
	convertedFiles_ = convert.getConvertedFilesPath();
}


//---> Return the list of files which are converted
std::vector<std::string> CodePublisher::getConvertedFiles()
{
	return convertedFiles_;
}

//---> Return the list of files which are converted
std::vector<std::string> CodePublisher::publishFiles(int argc, char** argv)
{
	processInputs(argc, argv);
	
	startConverting();
	
	return convertedFiles_;
}

//---> Return the list of files which matches the Regular Expressions
std::vector<std::string> CodePublisher::getFilteredFiles()
{
	return filteredFiles_;
}

#ifdef Test_Publisher



//-----<< This is the entry point to our application and tests the given requirements
int main(int argc, char *argv[])
{
	try
	{
		Ipublisher *publish = Ipublisher::create();
		std::cout << "\n ===========Req #1--->Created Executive,Loader,Dependencies,Display,HTMLConverter,RegexFilter Packages\n";
		std::cout << "\n ===========Req #2--->Loaded Files Based on Regexes provided as command line arguments:\n";

		publish -> processInputs(argc, argv);
		std::cout << "\n\n========Req #3 & #4--->Converting the Files to valid HTML Files, by wrapping tags B/W blocks, Dependency links\n\n";

		publish->startConverting();

		
		std::cout << "\n\nFinished Demonstrating\n\n";
		system("pause");
		return 0;
	}
	catch (std::exception &E) {
		std::cout << "\nException Occured as " << E.what();
		system("pause");
	}
	catch (...)
	{
		std::cout << "\nUnknown Exception Occured,Exiting the Application ";
		system("pause");
	}
}
#endif // Test_Publisher