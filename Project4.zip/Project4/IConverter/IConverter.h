#pragma once
class IConverter
{
public:
	IConverter* create();
	virtual void processCmdLines()=0;
	virtual void startConverting()=0;
	virtual void getConvertedFiles()=0;
	
};

