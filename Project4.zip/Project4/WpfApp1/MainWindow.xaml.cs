﻿///////////////////////////////////////////////////////////////////////
// MainWindow.xaml.cs - GUI for CodePublisher                      //
// ver 1.1                                                         //
// Sreekar Reddy,Sykam, CSE687 - Object Oriented Design, Spring 2019         //
///////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package provides a WPF-based GUI for Project4CodePublisher.  It's 
 * responsibilities are to:
 * - Provide a display of directory contents of a remote ServerPrototype.
 * - It provides a subdirectory list and a filelist for the selected directory.
 * - You can navigate into subdirectories by double-clicking on subdirectory
 *   or the parent directory, indicated by the name "..".
 *   Convert the files into valid HTML files and mark code,comments block
 * Required Files:
 * ---------------
 * Mainwindow.xaml, MainWindow.xaml.cs
 * Translator.dll
 * 
 * Maintenance History:
 * --------------------
 *  * ver 1.1 : 30 Apr 2019
 * - Added functionality to post message in the server and get the replies for posted messages and display them
 * ver 1.0 : 09 Apr 2019
 * - first release
 */

// Translator has to be statically linked with PublisherObjectFactory


using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Threading;
using MsgPassingCommunication;

namespace WPF
{
    
    
    public partial class MainWindow : Window
    {
        private string[] args ;
        int Serverport;
        
        
        private Stack<string> pathStack_ = new Stack<string>();
        private Translator translater;
        private CsEndPoint endPoint_;
        private Thread rcvThrd = null;
        private Dictionary<string, Action<CsMessage>> dispatcher_
          = new Dictionary<string, Action<CsMessage>>();
        //->>> intialize the window
        public MainWindow()
        {
            InitializeComponent();
        }

        //-->>after window is loaded do the following tasks
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // start Comm
            args  = Environment.GetCommandLineArgs();
            try
            {
                DirectoryPath.Text = args[1]; // read the command line arguments to get path
            }
            catch (Exception)
            {
                System.Windows.Forms.MessageBox.Show("Enter command line arguments properly", "error");
                return;
            }

            

            endPoint_ = new CsEndPoint();
            endPoint_.machineAddress = "localhost";
            try
            {
                endPoint_.port = Int32.Parse(args[2]); // read the command line arguments to  client port
            }
            catch(Exception)
            {
                System.Windows.Forms.MessageBox.Show("Enter command line arguments properly", "error");
                return;
            }
            translater = new Translator();
            translater.listen(endPoint_);
            try
            { 
                Serverport = Int32.Parse(args[3]); // read the command line arguments to server port
            }
            catch(Exception)
            {
                System.Windows.Forms.MessageBox.Show("Enter command line arguments properly", "error");
                return;

            }

            CsMessage msg = new CsMessage();

            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = Serverport;

            //Enquiring whther provided path was present or no
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            //Testing get directories requirements
            msg.add("command", "isPathExists");
            msg.add("path", args[1]);
            translater.postMessage(msg);

            pathStack_.Push(DirectoryPath.Text);
            // start processing messages
            processMessages();

            // load dispatcher
            loadDispatcher();

            // for first time when window is loaded test the requirements
            test1();
        }

        // ---->> Conatnis a set of tests to test the requirements
        private void test1()
        {
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = Serverport;
            
            CsMessage msg = new CsMessage();

            Console.WriteLine("\n\n===========================Req 2 Navigator inside server from client================");
            //Testing getfiles requirements
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            //Testing get directories requirements
            msg.add("command", "getDirs");  
            msg.add("path", pathStack_.Peek());
            translater.postMessage(msg);
            msg.remove("command");
            msg.add("command", "getFiles");
            translater.postMessage(msg);

            //Testing getFilteredfiles requirements
            msg.remove("command");
            msg.add("command", "getFilteredFiles");
            msg.add("patterns", Extensions.Text);
            msg.add("regexes", RegularExpression.Text);

            msg.add("options", "/s");

            translater.postMessage(msg);

            //Testing publishFiles requirements
            ConvertedFiles.Items.Add("Converting..");
            msg.remove("command");
            msg.add("command", "publishFiles");
            
            translater.postMessage(msg);

        }
        //---->Open File explorer to select the path
        private void ExplorerButtonClick(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog browse = new FolderBrowserDialog();
            browse.Description = "Select Directory To Convert into HTML";
            if(browse.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                DirectoryPath.Text = browse.SelectedPath;
            }
        }
         
       //----->After convert button is clicked start post a request to the server to start publishing them 
        private void ConvertButtonClick(object sender, RoutedEventArgs e)
        {
            ConvertedFiles.Items.Clear();
            ConvertedFiles.Items.Add("Converting...");
            
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = Serverport;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
          
            msg.add("path", pathStack_.Peek());
            msg.add("command", "publishFiles");
            msg.add("patterns", Extensions.Text);
            msg.add("regexes", RegularExpression.Text);
            if (SubDirectories.IsChecked.ToString() == "True")
                msg.add("options", "/s");
            else
                msg.add("options", "");
            translater.postMessage(msg);
           
        }
        //-----> On double click of the file download the published file from the server and open it in  application on user choice
        private void ConvertedFiles_DoubleClick(object sender, EventArgs e)
        {
            if (ConvertedFiles.SelectedItem != null)
            {
                if (ConvertedFiles.SelectedItem.ToString().Length != 0)
                {

                    CsEndPoint serverEndPoint = new CsEndPoint();
                    serverEndPoint.machineAddress = "localhost";
                    serverEndPoint.port = Serverport;
                    CsMessage msg = new CsMessage();
                    msg.add("to", CsEndPoint.toString(serverEndPoint));
                    msg.add("from", CsEndPoint.toString(endPoint_));
                   
                    msg.add("file", ConvertedFiles.SelectedItem.ToString());
                    msg.add("path", ConvertedFiles.SelectedItem.ToString());
                    string savepathDir = Directory.GetParent(Directory.GetParent(Directory.GetParent(Directory.GetParent(Directory.GetCurrentDirectory().ToString()).ToString()).ToString()).ToString()).ToString() + "\\DownloadedFromServer\\";
                    Directory.CreateDirectory(savepathDir);
                    msg.add("savePath", savepathDir + System.IO.Path.GetFileName(ConvertedFiles.SelectedItem.ToString()));
                    msg.add("command", "file");

                    translater.postMessage(msg);
                }
            }
        }
        

        //----> On doubleClicking the File open it in the default application
        private void NavigatorsFiles_DoubleClick(object sender, EventArgs e)
        {
            if (NavigatorFiles.SelectedItem != null)
            {
                try
                {
                    System.Diagnostics.Process.Start(DirectoryPath.Text+"\\"+NavigatorFiles.SelectedItem.ToString());
                }
                catch (Exception)
                {

                }

            }
        }

        //-------->On double clicking the Filtered Files Open it in default Application
        private void FilteredFiles_DoubleClick(object sender, EventArgs e)
        {
            if (FilteredFiles.SelectedItem != null)
            {
                try
                {
                    System.Diagnostics.Process.Start( FilteredFiles.SelectedItem.ToString());
                }
                catch (Exception)
                {

                }

            }
        }

        
        //----< process incoming messages on child thread >----------------

        private void processMessages()
        {
            ThreadStart thrdProc = () => {
                while (true)
                {
                    CsMessage msg = translater.getMessage();
                    string msgId = msg.value("command");
                 
                    if (dispatcher_.ContainsKey(msgId))
                        dispatcher_[msgId].Invoke(msg);
                }
            };
            rcvThrd = new Thread(thrdProc);
            rcvThrd.IsBackground = true;
            rcvThrd.Start();
        }
        //----< Clear all the items in Navigator >-------

        private void clearDirs()
        {
            Navigator.Items.Clear();
        }
        //----< Add all the item in Navigator >-------

        private void addDir(string dir)
        {
            Navigator.Items.Add(dir);
        }
        //----< Adding first item in the Navigator as .. so that user can go back >-------

        private void insertParent()
        {
            Navigator.Items.Insert(0, "..");
        }
        //----< Clear all the items in NavigatorFiles >-------

        private void clearFiles()
        {
            NavigatorFiles.Items.Clear();
        }
        //----< Clear all the items in ConvertedFiles >-------

        private void clearPublishedFiles()
        {
            ConvertedFiles.Items.Clear();
        }

        //----< Clear all the items in FilteredFiles >-------

        private void clearFilteredFiles()
        {
            FilteredFiles.Items.Clear();
        }

        //----< add the item in NavigatorFiles >-------

        private void addFile(string file)
        {
             NavigatorFiles.Items.Add(file);
        }

        //----< add the item in ConvertedFiles >-------

        private void addPublishedFile(string file)
        {
            ConvertedFiles.Items.Add(file);
        }

        //----< add the item in FilteredFiles >-------

        private void addFilteredFile(string file)
        {
            FilteredFiles.Items.Add(file);
        }

        
        //----< add client processing for message with key >---------------

        private void addClientProc(string key, Action<CsMessage> clientProc)
        {
            dispatcher_[key] = clientProc;
        }
        //----< load getDirs processing into dispatcher dictionary >-------

        private void DispatcherLoadGetDirs()
        {
            Action<CsMessage> getDirs = (CsMessage rcvMsg) =>
            {
                Action clrDirs = () =>
                {
                    clearDirs();
                };
                Dispatcher.Invoke(clrDirs, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("dir"))
                    {
                        Action<string> doDir = (string dir) =>
                        {
                            addDir(dir);
                        };
                        Dispatcher.Invoke(doDir, new Object[] { enumer.Current.Value });
                    }
                }
                Action insertUp = () =>
                {
                    insertParent();
                };
                Dispatcher.Invoke(insertUp, new Object[] { });
            };
            addClientProc("getDirs", getDirs);
        }
        //----< load getFiles processing into dispatcher dictionary >------

        private void DispatcherLoadGetFiles()
        {
            Action<CsMessage> getFiles = (CsMessage rcvMsg) =>
            {
                Action clrFiles = () =>
                {
                    clearFiles();
                };
                Dispatcher.Invoke(clrFiles, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("file"))
                    {
                        Action<string> doFile = (string file) =>
                        {
                            addFile(file);
                        };
                        Dispatcher.Invoke(doFile, new Object[] { enumer.Current.Value });
                    }
                }
            };
            addClientProc("getFiles", getFiles);
        }

        //----< load getPublishedFiles processing into dispatcher dictionary >------

        private void DispatcherLoadPublishedFiles()
        {
            Action<CsMessage> getPublishedFiles = (CsMessage rcvMsg) =>
            {
                Action clrFiles = () =>
                {
                    clearPublishedFiles();
                };
                Dispatcher.Invoke(clrFiles, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("file"))
                    {
                        Action<string> doFile = (string file) =>
                        {
                            addPublishedFile(file);
                        };
                        Dispatcher.Invoke(doFile, new Object[] { enumer.Current.Value });
                    }
                }
               
            };
            addClientProc("publishFiles", getPublishedFiles);
        }
        //----< load getFilteredFiles processing into dispatcher dictionary >------

        private void DispatcherLoadFilteredFiles()
        {
            Action<CsMessage> getFilteredFiles = (CsMessage rcvMsg) =>
            {
                Action clrFiles = () =>
                {
                    clearFilteredFiles();
                };
                Dispatcher.Invoke(clrFiles, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("file"))
                    {
                        Action<string> doFile = (string file) =>
                        {
                            addFilteredFile(file);
                        };
                        Dispatcher.Invoke(doFile, new Object[] { enumer.Current.Value });
                    }
                }

            };
            addClientProc("getFilteredFiles", getFilteredFiles);
        }
        //---->> Save the requested file content at client and open in browser/application based on user choice
        private void DispatcherLoadFileContent()
        {
            Action<CsMessage> getFileContent = (CsMessage rcvMsg) =>
            {
                var enumer = rcvMsg.attributes.GetEnumerator();
                
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("savedPath"))
                    {
                        
                        System.Windows.Forms.MessageBox.Show("File downloaded at " + enumer.Current.Value + "\n\nClick ok to display", "File Download Complete");
                       
                        //Depends on the user choice open whether it in notepad or browser
                        Dispatcher.Invoke(() =>
                        {
                            if (Notepad.IsChecked.ToString() == "True")
                            {
                                System.Diagnostics.Process.Start("notepad.exe", enumer.Current.Value);
                                
                            }
                            else
                            {
                                System.Diagnostics.Process.Start(enumer.Current.Value);
                            }
                        });
                    }
                }
            };
            addClientProc("getfile", getFileContent);
        }

        //---->> See if given path exists, if not set t default path(..)
        private void DispatcherLoadPathExists()
        {
            Action<CsMessage> isPathExists = (CsMessage rcvMsg) =>
            {
                var enumer = rcvMsg.attributes.GetEnumerator();

                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("isExist"))
                    {
                        string existance = enumer.Current.Value;
                        if (existance == "true")
                        {
                            return;
                        }
                        else
                        { 
                            System.Windows.Forms.MessageBox.Show("Given Path doesn't exist in server,  So setting path to default path(..) " , "Path Error");
                            Dispatcher.Invoke(() =>
                            {
                                DirectoryPath.Text = "..";
                                pathStack_.Pop();
                                pathStack_.Push("..");
                                test1();

                            });
                        }
                       
                    }
                }
            };
            addClientProc("isPathExists", isPathExists);
        }
        //----< load all dispatcher processing >---------------------------

        private void loadDispatcher()
        {
            DispatcherLoadGetDirs();
            DispatcherLoadGetFiles();
            DispatcherLoadPublishedFiles();
            DispatcherLoadFileContent();
            DispatcherLoadFilteredFiles();
            DispatcherLoadPathExists();
        }
        //--->>on double clicking append the path to previous path
        private void Navigator_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

            // build path for selected dir
            if (Navigator.SelectedItem == null)
                return;
            string selectedDir = Navigator.SelectedItem.ToString();
           
            string path;
            if (selectedDir == "..")
            {
                if (pathStack_.Count > 1)  // don't pop off "Storage"
                    pathStack_.Pop();
                else
                    return;
            }
            else
            {
                path = pathStack_.Peek() + "/" + selectedDir;
                pathStack_.Push(path);
            }

            Console.WriteLine("\n\n===========================Req 2 Navigator inside server from client================");
            // display path in Dir TextBlcok
            DirectoryPath.Text = removeFirstDir(pathStack_.Peek());

            // build message to get dirs and post it
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = Serverport;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "getDirs");
            msg.add("path", pathStack_.Peek());
            translater.postMessage(msg);

            // build message to get files and post it
            msg.remove("command");
            msg.add("command", "getFiles");
            translater.postMessage(msg);

            msg.remove("command");
            msg.add("patterns", Extensions.Text);
            msg.add("regexes", RegularExpression.Text);

            msg.add("options", "/s");


            msg.add("command", "getFilteredFiles");
            translater.postMessage(msg);
        }
        //----< strip off name of first part of path >---------------------

        private string removeFirstDir(string path)
        {
            string modifiedPath = path;
            int pos = path.IndexOf("/");
            modifiedPath = path.Substring(pos + 1, path.Length - pos - 1);
            return modifiedPath;
        }

    }

}
