#pragma once
#include<string>
#include<vector>
class Ipublisher
{
public:
	static Ipublisher* create();
	virtual void processInputs(int argc, char** argv) = 0;
	virtual void startConverting() = 0;
	virtual std::vector<std::string> getConvertedFiles() = 0;
	virtual std::vector<std::string> getFilteredFiles() = 0;
	virtual ~Ipublisher() {}
};
