#pragma once
/////////////////////////////////////////////////////////////////////////////
// Executive.h -                                                           //
//				                                                           //
//																	       //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////

#include<vector>
#include"Ipublisher1.h"

class asc
{
public:
	asc();
};
class CodePublisher1 : public Ipublisher
{
public:
	~CodePublisher1();
	void processInputs(int argc, char **argv);
	void startConverting();
	std::vector<std::string> getConvertedFiles();
	std::vector<std::string> getFilteredFiles();
private:
	std::vector<std::string> filteredFiles_;
	std::vector<std::string> convertedFiles_;
};

inline Ipublisher* Ipublisher::create()
{
	return new CodePublisher1();
}
