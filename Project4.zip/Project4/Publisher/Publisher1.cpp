#pragma once

#include<string>
#include<iostream>
#include "../HTMLConverter/HTMLConverter.h"
#include "../Display/Display.h"
#include "../Loader/Loader.h"
#include "Ipublisher1.h"
#include"Publisher1.h"
#include"pch.h"

asc::asc()
{

}
CodePublisher1::~CodePublisher1()
{
	filteredFiles_.clear();
	convertedFiles_.clear();
}

void CodePublisher1::processInputs(int argc, char** argv)
{
	/*int argc = 5;
	char *argv[] = {
	dirPath,
	dirPath,
	options,
	patterns,
	regexes
	};*/
	Loader load;
	load.loadFiles(argc, argv);
	filteredFiles_ = load.getLoadedFiles();

}

void CodePublisher1::startConverting()
{
	HtmlConverter convert;
	std::cout << filteredFiles_.size();
	convert.setFiles(filteredFiles_);
	convert.convertAllToHtml();
	convertedFiles_ = convert.getConvertedFilesPath();
}

std::vector<std::string> CodePublisher1::getConvertedFiles()
{
	return convertedFiles_;
}


std::vector<std::string> CodePublisher1::getFilteredFiles()
{
	return filteredFiles_;
}
//-----<< This is the entry point to our application and tests the given requirements
int main(int argc, char *argv[])
{
	try
	{
		std::cout << "\n ===========Req #1--->Created Executive,Loader,Dependencies,Display,HTMLConverter,RegexFilter Packages\n";
		Loader load;
		std::cout << "\n ===========Req #2--->Loaded Files Based on Regexes provided as command line arguments:\n";

		load.loadFiles(argc, argv);
		std::vector<std::string> filepaths = load.getLoadedFiles();
		std::cout << "\n\n========Req #3 & #4--->Converting the Files to valid HTML Files, by wrapping tags B/W blocks, Dependency links\n\n";
		HtmlConverter convert;
		convert.setFiles(filepaths);
		convert.convertAllToHtml();
		std::cout << "\n\n========Req #5--->Displaying the Files in Browser\n\n";
		Display display;
		display.displayInBrowser(convert.getConvertedFilesPath());
		std::cout << "\n\nFinished Demonstrating\n\n";
		system("pause");
		return 0;
	}
	catch (std::exception &E) {
		std::cout << "\nException Occured as " << E.what();
		system("pause");
	}
	catch (...)
	{
		std::cout << "\nUnknown Exception Occured,Exiting the Application ";
		system("pause");
	}
}
