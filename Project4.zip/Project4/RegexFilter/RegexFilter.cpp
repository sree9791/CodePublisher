/////////////////////////////////////////////////////////////////////////////
// RegexFilter.cpp - Contains a Test Stub to test Functionality              //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////


#ifdef TEST_RegexFilter

#pragma once
#include<vector>
#include<string>
#include<iostream>
#include "RegexFilter.h"
#include<regex>


//-----<<A test stub to test the functionality of the RegexFilter Class
int main(int argc, char* argv[])
{
	std::cout << "\nStarting a sample Test Case to test Regex_Filter" << std::endl;

	std::vector<std::string> Sample_regexes = { "[a-e](.*)","[e-z](.*)" };
	std::vector<std::string> Sample_string = { "hello.h","world.h","hello.cpp","world.cpp","Hi.exe","Hey" };
	std::vector<std::string> Sample_FilesPath = { "c:/temp/hello.h","c:/mydoc/temp/world.h","c:/temp/hello.cpp","c:/temp/doc/World.cpp","c:/temp/Hi.exe","c:/temp/Hey" };

	RegexFilter Re_string(Sample_regexes, Sample_string);

	Re_string.setOption("/d"); // This option is to apply regex on full string
	Re_string.Applyfilter();
	std::vector<std::string> Matched_string = Re_string.getMatchedStrings();

	
	std::cout << "\n\tFinished Filtering Strings\n";

	RegexFilter ReFiles(Sample_regexes, Sample_FilesPath);

	ReFiles.setOption("/f"); // This option is to apply regex only on file name in the entire file path
	ReFiles.Applyfilter();
	std::vector<std::string> Matched_Files = ReFiles.getMatchedStrings();

	
	std::cout << "\n\tFinished Filtering Files\n";
	system("pause");
}
#endif
