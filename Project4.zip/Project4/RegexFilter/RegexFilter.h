#pragma once
/////////////////////////////////////////////////////////////////////////////
// RegexFilter.h - Filters Regex Matched Strings                           //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * ==================
 * This Package provides class of the same name to filter the strings on given Regexes
 *
 * Required Files:
 * ===============
 *  RegexFilter.h
 *  FileSystem.h
 *
 * Maintenance History:
 * ver 1.0 : 05 Feb 2019
 * - first release
 */

#include<iostream>
#include<vector>
#include<regex>
#include "..//FileSystem/FileSystem.h"

class RegexFilter
{
public:
	using Regexes = std::vector<std::string>;
	using Matchednames = std::vector<std::string>;
	using Allstrings = std::vector<std::string>;

	RegexFilter();
	~RegexFilter();
	RegexFilter(const Regexes& regexes, const Allstrings& allstrings);

	void Applyfilter();
	void filterStrings(const Regexes& regexes_, const Allstrings& allstrings_, const std::string& option_);
	const std::vector<std::string>& getMatchedStrings();
	void setOption(const std::string& option);
	void clearMatchedNames();

private:
	Regexes regexes_;

	Matchednames matchednames_;
	Allstrings allstrings_;
	std::string option_;

};

//----->> A constructor to create the instances for the class and set default values
inline RegexFilter::RegexFilter()
{
	option_ = "/d";    // default option to apply regex on entire string
}

//----->> A destructor to deallocate the memory when it is not in use
inline RegexFilter::~RegexFilter()
{
	option_ = "/0";    
}

//------>> An overloaded Constructor to create the instances and sets the regexes and strings to process later
inline RegexFilter::RegexFilter(const Regexes& regexes, const Allstrings& allstrings)
{
	regexes_ = regexes;
	allstrings_ = allstrings;
	option_ = "/d";    // default option to apply regex on entire string
}


//----<< This option is for, to which part of the string we need to apply regex
//        ( e.g: entire string or if filepath then apply only on filename 

inline void RegexFilter::setOption(const std::string& option)
{
	option_ = option;
}

//-------<<Return  the strings which matched the regex
inline const std::vector<std::string>& RegexFilter::getMatchedStrings()
{
	return matchednames_;
}

//--------<< Calls filterStrings to apply regex
inline void RegexFilter::Applyfilter()
{
	//std::cout << "\n\n\tFollowing Matched given Regex:\n";
	filterStrings(regexes_, allstrings_, option_);
}

//-------<< Apply regex on each string based on the option we set
inline void RegexFilter::filterStrings(const Regexes& regexes_, const Allstrings& allstrings_, const std::string& option_)
{	
	clearMatchedNames();
	for (auto each_regex : regexes_)
	{
		std::regex re(each_regex);
		//std::cout << "\n\n\tFiles Matching the Regex " << each_regex << " are:\n";

		int matched_count = 0;
		for (auto each_string : allstrings_)
		{
			// if option is '/f' then we need apply regex only on filename
			if (option_.compare("/f") == 0)
			{
				std::string filename = FileSystem::Path::getName(each_string);
				if (std::regex_match(filename, re))
				{
					++matched_count;
					if (std::find(matchednames_.begin(), matchednames_.end(), each_string) == matchednames_.end())
					{
						matchednames_.push_back(each_string); //if element not there push
					}
					//std::cout << "\t  * " << each_string << std::endl;
				}
			}
			else if (option_.compare("/d") == 0)
			{// if option is '/d' then we need apply regex on entire string
				if (std::regex_match(each_string, re))
				{
					++matched_count;
					if (std::find(matchednames_.begin(), matchednames_.end(), each_string) == matchednames_.end())
					{
						matchednames_.push_back(each_string); //if element not there push
					}
					//std::cout << "\t  * " << each_string << std::endl;
				}
			}
			else
				return;
		}
		if (matched_count == 0)
		{
			std::cout << "\n\t   ***No Files Matched this Regex.***\n";
		}

	}
}

//-------< making the Matchednames_ empty
inline void RegexFilter::clearMatchedNames()
{
	matchednames_.clear();
}
