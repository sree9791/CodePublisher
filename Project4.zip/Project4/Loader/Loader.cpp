#pragma once
/////////////////////////////////////////////////////////////////////////////
// Loader.cpp -  A  test stub to load the files based on the regexes     //
//				                                                           //
//																	       //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/*/////////////////////////////////////////////////////////////////////////*/


#include "Loader.h"
//------> A  test stub to load the files based on the regexes  
int main(int argc, char*  argv[])
{
	Loader load;
	load.loadFiles(argc, argv);
	std::vector<std::string> loadedFiles = load.getLoadedFiles();
	system("pause");
	return 1;
}
