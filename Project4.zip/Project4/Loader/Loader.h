#pragma once

/////////////////////////////////////////////////////////////////////////////
// Loader.h - Filters and loads Regex Matched Files                        //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * ==================
 * This Package provides class of the same name to filter the files which matches the given Regexes
 *
 * Required Files:
 * ===============
 *  Loader.h
 *  FileSystem.h
 *  DirExplorerN
 *  StringUtilities.h
 *  CodeUtilities.h
 * Maintenance History:
 * ver 1.0 : 05 Mar 2019
 * - first release
 */



#include "../DirExplorer-Naive/DirExplorerN.h"
#include "../Utilities/StringUtilities/StringUtilities.h"
#include "../Utilities/CodeUtilities/CodeUtilities.h"
#include "../RegexFilter/RegexFilter.h"
#include <iostream>
using namespace CodeUtilities;
using namespace FileSystem;


//------<< A helper guide how to run the application 
ProcessCmdLine::Usage customUsage()
{
	std::string usage;
	usage += "\n  Command Line: path [/option]* [/pattern]*";
	usage += "\n    path is relative or absolute path where processing begins";
	usage += "\n    [/option]* are one or more options of the form:";
	usage += "\n      /s - walk directory recursively";
	//usage += "\n      /h - hide empty directories";
	//usage += "\n      /a - on stopping, show all files in current directory";
	usage += "\n    [pattern]* are one or more pattern strings of the form:";
	usage += "\n      *.h *.cpp *.cs *.txt or *.*";
	usage += "\n    [regex]* are one or more regular expressions of the form:";
	usage += "\n    ([a-z].*) ([A-S].*)";
	usage += "\n";
	return usage;
}

class Loader
{
public:
	Loader();
	~Loader();
	void loadFiles(int argc, char *argv[]);
	std::vector<std::string> getLoadedFiles();
private:
	std::vector<std::string> filteredFiles_;
};

//-------------> A constructor to instantiate the object
inline Loader::Loader()
{
}

//-------> A destructor to deallocate the memory
inline Loader::~Loader()
{
}

// --------------> Filters the files based on the regexes provided by the user
inline void Loader::loadFiles(int argc, char *argv[])
{
	CodeUtilities::ProcessCmdLine pcl(argc, argv);
	pcl.usage(customUsage());
	//preface("Command Line: ");

	//pcl.showCmdLine();
	
	if (pcl.parseError())
	{
		pcl.usage();
		return ;
	}
	DirExplorerN Dir_Exp(pcl.path());
	for (auto patt : pcl.patterns())
	{
		
		Dir_Exp.addPattern(patt); // add all wildcard patterns
	}
	if (pcl.hasOption('s'))
		Dir_Exp.recurse();
	
	//std::cout << "\n\n  Files We Found are:\n";
	Dir_Exp.search();							// Extract all files in directory which matches the wildcards
	auto allFiles = Dir_Exp.allFileNames();
	
	RegexFilter Reg_exp(pcl.regexes(), allFiles);
	Reg_exp.setOption("/f");						// filter the extracted files based on regexes
	Reg_exp.Applyfilter();
	filteredFiles_ = Reg_exp.getMatchedStrings();
}

//------------> return the filtered files
inline std::vector<std::string> Loader::getLoadedFiles()
{
	return filteredFiles_;
}
