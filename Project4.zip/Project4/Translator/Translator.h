#pragma once
/////////////////////////////////////////////////////////////////////////
// Translator.h - Translates messages to/from managed and native types //
// ver 1.1                                                             //
// Sreekar Reddy, Sykam CSE687 - Object Oriented Design, Spring 2019 
//Source: Jim, Fawcett CSE687 - Object Oriented Design, Spring 2019
/////////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
* ---------------------
*  This C++\Cli Package contains one class, Translater.  It's purpose is to convert
*  managed messages, CsMessage, to native messages, Message, and back.
*
*  Required Files:
* -----------------
*  Translator.h, Translator.cpp
*  Icomm.h, CommLibWrapper.h
*  
*  Required References:
* ----------------------
*  Message.lib
*  CommLibWrapper.lib
*  
*
*
*  Maintenance History:
* ----------------------
*  ver 1.1 : 4/30/2019
*  - TO support translation of messages from C++ to C# and backforth
*  ver 1.0 : 4/09/2019
*  - first release
*/

// Project > Properties > C/C++ > Language > Conformance mode set to No
// Add references to System, System.Core

#include<string>
#include "CsMessage.h"
#include "../CppCommWithFileXfer/MsgPassingComm/IComm.h"
#include "../CommLibWrapper/CommLibWrapper.h"

using namespace System;
using namespace System::Collections::Generic;
using namespace MsgPassingCommunication;

public ref class Translator
{
public:
	Translator();
	~Translator();
	
	
	void listen(CsEndPoint^ ep);
	void postMessage(CsMessage^ msg);
	CsMessage^ getMessage();
	CsMessage^ fromMessage(Message& msg);
	Message fromCsMessage(CsMessage^ csMsg);
private:
	// convert System::String to std::string
	std::string sysStrToStdStr(String^ str);
	// convert std::string to System::String
	String^ stdStrToSysStr(const std::string& str);
	// convert vector of std::string to list of System::String
	List<String^>^ stdVectorToSysList(std::vector<std::string> stringVector);
	// convert Array of System::String to char**
	char** sysStringArrToCharArr(array<String^>^ argv);
	// convert System::String to Char*
	char* sysStrToCharArr(String^);
	
	CsEndPoint^ ep_;
	MsgPassingCommunication::CommFactory* pFactory;
	MsgPassingCommunication::IComm* pComm;

};

