///////////////////////////////////////////////////////////////////////////
// Translator.cpp - Translates messages to/from managed and native types //
// ver 1.1                                                               //
// Sreekar Reddy,Sykam, CSE687 - Object Oriented Design, Spring 2019  
// Source: Jim, Fawcett, CSE687 - Object Oriented Design, Spring 2019
///////////////////////////////////////////////////////////////////////////

#include "Translator.h"
#include<vector>
#include<iostream>

//---> A constructor which initialises our Main CodePublisher object
Translator::Translator()
{
	
	ep_ = gcnew CsEndPoint;
	
}

//--> A destructor to deallocate the memory
Translator::~Translator()
{
	
}



//----< convert std::string to System.String >-------------------------
String^ Translator::stdStrToSysStr(const std::string& str) {
	return gcnew String(str.c_str());
}

//----< convert System.String to std::string >-------------------------
std::string Translator::sysStrToStdStr(String^ str) {
	std::string temp;
	for (int i = 0; i < str->Length; ++i)
		temp += char(str[i]);
	return temp;
}
//--> convert System::String to Char*
char* Translator::sysStrToCharArr(String^ str)
{
	
	
	std::string stdString = sysStrToStdStr(str);
	char *temp = new char[stdString.length()+1];
	

	for (size_t i = 0; i < stdString.length(); ++i)
		temp [i] = char(stdString[i]);
	temp[stdString.length()] = '\0';
	return temp;
}
// convert Array of System::String to char**
char** Translator::sysStringArrToCharArr(array<String^>^ argv)
{
	

	int a = argv->Length;
	char **temp = new char*[a];
	for (int i = 0; i < argv->Length; ++i)
		temp[i] = sysStrToCharArr(argv[i]);

	return temp;
}

//-->> convert vector of std::string to list of System::String
List<String^>^ Translator::stdVectorToSysList(std::vector<std::string> stringVector)
{
	List<String^>^ sysList = gcnew List<String^>();
	for (std::string str :stringVector)
	{
		sysList->Add(stdStrToSysStr(str));
	}
	return sysList;
}

//----< set client listen endpoint and start Comm >------------------

void Translator::listen(CsEndPoint^ ep)
{
	//std::cout << "\n  using CommFactory to create instance of Comm on native heap";
	ep_->machineAddress = ep->machineAddress;
	ep_->port = ep->port;
	pFactory = new CommFactory;
	pComm = pFactory->create(Sutils::MtoNstr(ep_->machineAddress), ep_->port);
	pComm->start();
	delete pFactory;
}


//--->>> which will post the request in queue in server(pcomm)
 void Translator::postMessage(CsMessage^ csMsg)
{
	
	Message msg = this->fromCsMessage(csMsg);
	std::cout << "\n===================req #1-Part 1 message posted to server===========\n";
	msg.show();
	pComm->postMessage(msg);
}
//----< get message from Comm >--------------------------------------
 CsMessage^ Translator::getMessage()
{
	 
	Message msg = pComm->getMessage();
	std::cout << "\n===================req #1 - Part 2   got message from server===========\n";
	msg.show();
	CsMessage^ a = fromMessage(msg);
	return fromMessage(msg);
}

//----< convert native message to managed message >------------------

CsMessage^ Translator::fromMessage(Message& msg)
{
	CsMessage^ csMsg = gcnew CsMessage;
	Message::Attributes attribs = msg.attributes();
	int sz = attribs.size();
	for (auto attrib : attribs)
	{
		csMsg->add(Sutils::NtoMstr(attrib.first), Sutils::NtoMstr(attrib.second));
	}
	CsMessage^ b = csMsg;
	return csMsg;
}
//----< convert managed message to native message >------------------

Message Translator::fromCsMessage(CsMessage^ csMsg)
{
	Message msg;
	auto enumer = csMsg->attributes->GetEnumerator();
	while (enumer.MoveNext())
	{
		String^ key = enumer.Current.Key;
		String^ value = enumer.Current.Value;
		msg.attribute(Sutils::MtoNstr(key), Sutils::MtoNstr(value));
	}
	return msg;
}