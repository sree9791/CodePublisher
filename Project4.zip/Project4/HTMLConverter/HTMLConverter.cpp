#pragma once
/////////////////////////////////////////////////////////////////////////////
// HTMLConverter.cpp Contains a Test Stub to convert fies into Html files  //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////


#ifdef TEST_HTMLConverter

#pragma once
#include<vector>
#include<string>
#include<iostream>
#include "HTMLConverter.h"
#include "../FileSystem/FileSystem.h"



//------<< A test Stub to test the functionality of the HTMLConverter
int main(int argc, char* argv[])
{
	std::vector<std::string> filepaths;
	filepaths = FileSystem::Directory::getFiles(); //Getting list of files in current directory

	std::cout << "Starting Converting the Files into HTML\n";

	HtmlConverter convert;
	convert.setFiles(filepaths); //Path of the files need to be convert
	convert.convertAllToHtml();

	auto output_files_path = convert.getConvertedFilesPath();

	std::cout << "\n-----------Converted Files are : ---------- \n\n";

	for (auto each_file : output_files_path)
	{
		std::cout <<" @ Converted and Stored at: " << each_file << " as:" << std::endl;
		std::string file_data = convert.readFileData(each_file);
		std::cout << file_data<<"\n\n\n";
		std::cout << "==============================================================\n\n";
		
	}


	std::cout << "\nFinished Converting Files\n";

	system("pause");
}

#endif