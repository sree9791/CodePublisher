#pragma once
/////////////////////////////////////////////////////////////////////////////
// HTMLConverter.h - To convert files to html                              //
// ver 1.1                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * HTMLConverter provides a class, of the same name, that converts
 * all files provided into html format , marks the code sections if wanted and saves the converted html files
 *
 *
 * Required Files:
 * ---------------
 * HTMLConverter.h
 * FileSystem.h
 * Parser.h
 * ActionsAndRules.h 
 * ConfigureParser.h
 * Utilities.h
 * Toker.h
 * Semi.h
 * Dependencies.h
 *
 *
 * Maintenance History:
 * --------------------
 * ver 1.1 : 05 Mar 2019
 * - Added functionality to wrap tags around code blocks
 * - Added functionality to add links for headers
 * ver 1.0 : 05 Feb 2019
 * - first release
 *
 * Planned Additions and Changes:
 * ------------------------------
 * - none yet
 */



#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include "../FileSystem/FileSystem.h"
#include "../Utilities/Utilities.h"
#include "../Tokenizer/Toker.h"
#include "../SemiExpression/Semi.h"
#include "../Parser/Parser.h"
#include "../Parser/ActionsAndRules.h"
#include "../Parser/ConfigureParser.h"
#include "../Dependencies/Dependencies.h"
#include <queue>

using namespace Lexer;
using namespace Utilities;
using Demo = Logging::StaticLogger<1>;

//#define Util StringHelper

using namespace CodeAnalysis;

class HtmlConverter
{
public:
	using Filepaths = std::vector<std::string>;

	HtmlConverter();
	~HtmlConverter();
	void convertToHtml(const std::string& filepath);
	void convertAllToHtml();
	void setFiles(Filepaths& filepaths);
	std::string readFileData(const std::string& filepath);
	void WriteData(const std::string&, const std::string&);
	Filepaths getConvertedFilesPath() const;
	std::map<std::string, std::vector<std::vector<size_t>>> getAST(const std::string&);
	std::vector<std::string> splitString(std::string& str,const char&);
	std::string replaceSymbol(std::string filedata, const char& symbol, const std::string& replacewith);
	std::string markCodeBlocks(std::string filedata, const std::string& filepath);
	std::string accumulate(const std::vector<std::string>& allStrings);
	std::string markComments(std::string& fileData);
	std::string addDependencyLinks(const std::string&, std::string fileContent);
	void setMarkCPPCodeSections();
	void clearMarkCPPCodeSections();
private:
	Filepaths filepaths_;
	Filepaths output_files_path_;
	bool markCPPCodeSections_;
};

//-----<< A constructor to create the instances for this class
inline HtmlConverter::HtmlConverter()
{
	markCPPCodeSections_ = true;// to also add the tags around classes, functions and comments
}

//------<< A destructor to deallocate the memory when it is not in use 
inline HtmlConverter::~HtmlConverter()
{

}

//----< Set the list of files to convert to html format
inline void HtmlConverter::setFiles(Filepaths& filepaths)
{
	filepaths_ = filepaths;
}

//----< Start converting the files
inline void HtmlConverter::convertAllToHtml()
{
	std::cout << "\n\n==================Req 3 Started Converting Files: in server ====================\n";

	for (auto each_file : filepaths_)
	{
		try
		{
			convertToHtml(each_file);
		}
		catch (std::exception &E) {
			std::cout << "\n#####Unable to Convert the File "<<each_file<<" Exception Occured as " << E.what();
		}
		catch (...)
		{
			std::cout << "\n#####Unable to Convert the File " << each_file << " Unknown Exception Occured,Exiting the Application ";
		}
	}

	std::cout << "\n\n  Finished Converting\n";
}


//--------->  To add the href links for all the user headers used and which are in same folder
inline std::string HtmlConverter::addDependencyLinks(const std::string& filePath, std::string fileContent)
{
	std::vector<std::string> dependencyHeaderTable;
	std::vector<std::vector<int>> dependencyPositionTable;
	Dependencies dependency;

	std::vector<std::string> fileLines = splitString(fileContent, '\n');

	dependency.fileDependencies(filePath, fileLines);// getting all dependencies here
	dependencyHeaderTable = dependency.getDependencyHeadersTable();
	dependencyPositionTable = dependency.getDependencyPositionsTable();
	std::string fileDirectory = FileSystem::Path::getPath(filePath);
	std::string curDirectory = FileSystem::Path::getFullFileSpec("..\\convertedPages");
	std::vector<std::string> filesInCurDir = FileSystem::Directory::getFiles(curDirectory);
	
	for (size_t i = 0; i < dependencyHeaderTable.size(); i++)
	{
		std::string dependencyLink;
		// if dependency file is also converted then we link to the converted file otherwise original source code file
		if (std::find(filesInCurDir.begin(), filesInCurDir.end(), dependencyHeaderTable[i] + ".html") != filesInCurDir.end())
		{
			dependencyLink = "<a href = '" + curDirectory + "\\" + dependencyHeaderTable[i] + ".html" + "' target='_blank'>";

		}
		else
		{
			dependencyLink = "<a href = '" + fileDirectory + "\\" + dependencyHeaderTable[i] + "' target='_blank'>";
		}

		int lineNumber = dependencyPositionTable[i][0];
		int dependencyStartsAt = dependencyPositionTable[i][1];
		int dependencyEndsAt = dependencyPositionTable[i][2];
		fileLines[lineNumber].replace(dependencyStartsAt, 0, dependencyLink);
		fileLines[lineNumber].replace(dependencyEndsAt + dependencyLink.size(), 0, "</a>");
		std::cout << dependencyHeaderTable[i]<<", ";
	}

	if (dependencyHeaderTable.size() == 0)
	{
		std::cout << " None Found ";
	}
	
	return accumulate(fileLines);
}
//--------< Replace the character with given string 
inline std::string HtmlConverter::replaceSymbol(std::string filedata, const char& symbol,const std::string& replacewith)
{
	std::size_t index;
	do
	{
		// Converting all occurrances '>' to printable format
		index = filedata.find(symbol);
		if (index != std::string::npos)
		{
			filedata.replace(index, 1, replacewith);
		}
	} while (index != std::string::npos);
	return filedata;
}

//----< Convert each file by appending the html template and original file
inline void HtmlConverter::convertToHtml(const std::string& filepath)
{
	std::string HtmlHeaderPath = "../Templates\\Html_Header_Template.txt";
	std::string HtmlFooterPath = "../Templates\\Html_Footer_Template.txt";
	std::string filename = FileSystem::Path::getName(filepath);

	std::string outputFilePath = "../convertedPages\\" + filename + ".html";
	
	
	std::string HtmlHeaderContent="";
	std::string HtmlFooterContent="";
	std::cout << "\n\t @Converting " << FileSystem::Path::getFullFileSpec(outputFilePath);
	
	try
	{
		HtmlHeaderContent = readFileData(HtmlHeaderPath);

		HtmlFooterContent = readFileData(HtmlFooterPath);
	}
	catch (std::exception e)
	{
		std::cout << "\n         ***********Make Sure HTML Templates were present***********\n";
	}
	catch (...)
	{
		std::cout << "\n         ***********Make Sure HTML Templates were present***********\n";
	}
	std::string FileContent = readFileData(filepath);
	
	FileContent = replaceSymbol(FileContent, '<', "&lt");
	FileContent = replaceSymbol(FileContent, '>', "&gt");
	
	//if markCPPCodeSections is true then only tag all the code sections like functions,comments,classes
	if (markCPPCodeSections_)
	{
		
		FileContent = markCodeBlocks(FileContent, filepath);

		FileContent = markComments(FileContent);
		 

		std::cout << "\t\t+Added dependency Links for " << FileSystem::Path::getName(outputFilePath) << " linked to ";
		FileContent = addDependencyLinks(filepath, FileContent);
	}

	if (FileSystem::Directory::exists("../convertedPages") == false)
	{
		FileSystem::Directory::create("../convertedPages");   //Create directory if not exists
	}
	
	WriteData(HtmlHeaderContent + FileContent + HtmlFooterContent, outputFilePath);
	// Store the path of the converted file where it is saved 
	output_files_path_.push_back(FileSystem::Path::getFullFileSpec(outputFilePath));
	
	
}

// --------> Add tags around all multiline and single line comments
inline std::string HtmlConverter::markComments(std::string& fileData)
{
	std::vector<std::string> fileLines = splitString(fileData, '\n');
	bool multilineCommentStart = false;
	bool multilineCommentEnd = false;
	bool singlelineComment = false;
	int nestedMultiCommentCount = 0;
	std::string singleCommentDivTag = " <div class='COMMENT'>/";
	std::string multiCommentDivTag = " <div class='COMMENT'>/";
	for (size_t i = 0; i < fileLines.size(); i++)
	{
		std::string curLine = fileLines[i];
		for (size_t j = 0; j < curLine.size() && j+1 != curLine.size(); j++)
		{
			// check for single line comments
			if (curLine[j] == '/' && curLine[j + 1] == '/'&& nestedMultiCommentCount == 0)
			{
				singlelineComment = true;
				fileLines[i].replace(j, 1, singleCommentDivTag);
				break;
			}
			else if (curLine[j] == '/' && curLine[j + 1] == '*') // check for multi line comments
			{
				++nestedMultiCommentCount;
				fileLines[i].replace(j, 1, multiCommentDivTag);
			}
			else if (curLine[j] == '*' && curLine[j + 1] == '/' && nestedMultiCommentCount > 0)//closing multi comments
			{
				--nestedMultiCommentCount;
				fileLines[i].replace(j, 2, " */</div>");
			}
		}
		if (singlelineComment)//closing single line comments
		{
			fileLines[i].replace(fileLines[i].size()-1,1, " </div>");
			singlelineComment = false;
		}
	}
	return accumulate(fileLines);
}
//------------> add div tags for all the class and function blocks
inline std::string HtmlConverter::markCodeBlocks(std::string filedata, const std::string& filepath)
{

	std::vector<std::string> fileLines;
	std::map<std::string, std::vector<std::vector<size_t>>> AST;
	AST = getAST(filepath);
	fileLines = splitString(filedata, '\n');
	fileLines.push_back(" ");
	
	std::string classDivTag = " <div class = 'CLASS' > {";
	std::string functionDivTag = " <div class = 'FUNCTION' > {";
	
	for (const auto& eachType : AST)
	{
		std::string type = eachType.first;
		for (auto each_class_block : eachType.second)
		{
			std::string s = filepath;
			size_t startIndex = each_class_block[0]-1;
			
			
			size_t blockStartAt = fileLines[startIndex].find('{');
			
			if (type == "class")
			{
				fileLines[startIndex].replace(blockStartAt, 1, classDivTag);
				size_t endIndex = each_class_block[1] - 2;
				
				size_t blockEndsAt = fileLines[endIndex].find('}');
				
				fileLines[endIndex].replace(blockEndsAt, 2, "}; </div>");
				
			}
			if (type == "function")
			{	
				fileLines[startIndex].replace(blockStartAt, 1, functionDivTag);
				size_t endIndex = each_class_block[1] - 1;
				size_t blockEndsAt = fileLines[endIndex].find('}');
				fileLines[endIndex].replace(blockEndsAt, 1, "} </div>");
			}
		}
	}
	
	return accumulate(fileLines);
}
//----------> Convert vector of strings to single string
inline std::string HtmlConverter::accumulate(const std::vector<std::string>& allStrings)
{
	std::string singleString;
	for (std::string str : allStrings)
	{
		singleString += str+"\n";
	}
	return singleString;
}
//----< return saved path of all converted files
inline HtmlConverter::Filepaths HtmlConverter::getConvertedFilesPath() const
{
	return output_files_path_;
}

//----< read File content
inline std::string HtmlConverter::readFileData(const std::string& filepath)
{
	
	std::ifstream inputFileHandler(filepath, std::ios::binary | std::ios::app);
	inputFileHandler.seekg(0, inputFileHandler.end);
	int length = static_cast<int>(inputFileHandler.tellg());
	inputFileHandler.seekg(0, inputFileHandler.beg);
	char * buffer = new char[length + 1];


	inputFileHandler.read(buffer, length);
	buffer[length] = '\0';

	if (inputFileHandler.gcount() != length - 1)
	{
		std::string filecontent(buffer);
		inputFileHandler.close();

		delete[] buffer;

		return filecontent;
	}
	else
	{
		std::string filecontent(buffer);
		inputFileHandler.close();
		delete[] buffer;
		return std::string("error: only " + std::to_string(inputFileHandler.gcount()) + " characters in the file could be read");
	}

}

//----< Write the data into the file
inline void HtmlConverter::WriteData(const std::string& content, const std::string& outputpath)
{

	std::ofstream outputFileHandler(outputpath);

	outputFileHandler << content;
	outputFileHandler.close();
}

// -----------> splits the string with the give delimiter
inline std::vector<std::string> HtmlConverter::splitString(std::string& str,const char& delimiter )
{
	std::vector<std::string> splittedStrings;

	std::string::size_type pos = 0;
	std::string::size_type prev = 0;
	while ((pos = str.find(delimiter, prev)) != std::string::npos)
	{
		splittedStrings.push_back(str.substr(prev, pos - prev));
		prev = pos + 1;
	}

	// To get the last substring (or only, if delimiter is not found)
	splittedStrings.push_back(str.substr(prev));

	return splittedStrings;
}

// ----------------> Getting full syntax tree which finds the type of the block and gives the position
inline std::map<std::string, std::vector<std::vector<size_t>>> HtmlConverter::getAST(const std::string& filepath)
{
	ConfigParseForCodeAnal configure;
	Parser* pParser = configure.Build();
	std::map<std::string, std::vector<std::vector<size_t>>> ASTResult;
	std::string name;

	try
	{
		if (pParser)
		{
			name = FileSystem::Path::getName(filepath);
			if (!configure.Attach(filepath))
			{
				std::cout << "\n  could not open file " << name << std::endl;
				return ASTResult;
			}
		}
		else
		{
			std::cout << "\n\n  Parser not built\n\n";
			return ASTResult;
		}
		// save current package name
		Repository* pRepo = Repository::getInstance();
		pRepo->package() = name;
		// parse the package
		while (pParser->next())
		{
			pParser->parse();
		}
		// final AST operations
		ASTNode* pGlobalScope = pRepo->getGlobalScope();

		// walk AST, computing complexity for each node and record in AST node's element
		complexityEval(pGlobalScope);
		ASTResult = TreeWalk(pGlobalScope, false, true);// Walk AST, store each element in vector as a value and key is filename

		return ASTResult;
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
		std::cout << "\n  exception caught at line " << __LINE__ << " ";
		std::cout << "\n  in package \"" << name << "\"";
		return ASTResult;
	}
}
//------> To set markCPPCodeSections to true, so that functions and classes will also be tagged
inline void HtmlConverter::setMarkCPPCodeSections()
{
	markCPPCodeSections_ = true;
}

//------> To clear markCPPCodeSections to false, so that file will convert to html without tagging functions,classes,comments
inline void HtmlConverter::clearMarkCPPCodeSections()
{
	markCPPCodeSections_ = false;
}
