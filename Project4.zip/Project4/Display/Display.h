#pragma once
/////////////////////////////////////////////////////////////////////////////
// Display.h - To Display the Results in the application we want           //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package provides classes:
* - Display    To display the files one by one in the application we want .
*                 The next file will display only after closing the current display.
*
* --------------
* Required Files:
*   Process.h
*   Display.h
*
* Maintenance History:
* --------------------
* ver 1.0 : 05 Feb 2019
* - first release
*
*
* Planned Additions and Changes:
* ------------------------------
*
* - none yet
 *
*/

#include "../Process/Process.h"
#include <iostream>
#include <conio.h>
#include<vector>
#include <string>
#include<fstream>


class Display
{
public:
	using Filespath = std::vector<std::string>;

	Display();
	~Display();
	void displayInBrowser(const Filespath&);
};

//-----< A constructor used to create instances
inline Display::Display()
{

}

//-----< A destructor to deallocate the memory when it is not in use
inline Display::~Display()
{

}

//----< Display the Content in the Browser
inline void Display::displayInBrowser(const Display::Filespath& filepaths)
{

	Process process;
	process.title("Display");
	std::string appPath = "c:/windows/system32/cmd.exe";  // path to application to start
	process.application(appPath);

	std::ifstream WebBrowserFile("../Templates/WebBrowserPath.txt");
	std::string WebBrowserPath((std::istreambuf_iterator<char>(WebBrowserFile)),(std::istreambuf_iterator<char>()));

	for (int i = 0 ;  i< static_cast<int>(filepaths.size()); ++i)
	{
		try
		{
			// asking browser to display the html files.
			std::string cmdLine = "/c start /wait \"\" \"" + WebBrowserPath + "\" -noframemerging " + filepaths[i];
			process.commandLine(cmdLine);
			std::cout << "\nOpening File : " << filepaths[i];

			process.create();
			CBP callback = []() { std::cout << ""; };
			process.setCallBackProcessing(callback);
			process.registerCallback();

			WaitForSingleObject(process.getProcessHandle(), INFINITE);  // wait for created process to terminate

			if (i >= 2)
			{
				break;//after 3 are displayed come out.
			}
		}
		catch (std::exception &E) {
			std::cout << "\nException Occured as " << E.what();
			std::cout << "\nprobably add " << WebBrowserPath <<"in Environment Variable or provide corrrect browser path";
			system("pause");
		}
		catch (...)
		{
			std::cout << "\nUnknown Exception Occured,Exiting the Application ";
			system("pause");
		}
	}

	std::cout << "\n\n  Displayed Upto 3 Files Only";
	std::cout.flush();

}
