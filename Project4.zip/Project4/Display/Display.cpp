#pragma once
////////////////////////////////////////////////////////////////////////////////
// Display.cpp Contains a Test Stub to Dislay the files in webbrowser 1 by 1  //
// ver 1.0                                                                    //
// Language:    Visual C++, Visual Studio 2017                                //
// Application: Most Projects, CSE687 - Object Oriented Design                //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10              //
//                                                                            //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University     //
//              (315) 243 7232, ssykam@syr.edu                                //
////////////////////////////////////////////////////////////////////////////////


#ifdef TEST_HTMLConverter

#include<vector>
#include<string>
#include<iostream>
#include "Display.h"
#include "../FileSystem/FileSystem.h"



//--------< A test stub to test the functionality of Display
int main(int argc, char* argv[])
{
	std::cout << "\n  Demonstrating code pop-up in ieexplorer";
	std::cout << "\n ======================================";
	std::cout << "\n  Will start ieexplorer for number of files times and each time wait for termination.";
	std::cout << "\n  You need to kill each window (upper right button) to continue.";

	std::vector<std::string> filenames;
	filenames = FileSystem::Directory::getFiles(); //Getting list of files in current directory

	std::string curdir = FileSystem::Directory::getCurrentDirectory();

	std::vector<std::string> filepaths;

	for (auto each_file : filenames)
	{
		filepaths.push_back(curdir + "/" + each_file);
	}


	Display display;
	display.displayInBrowser(filepaths);

	std::cout << "\nAll Files were opened\n";

}

#endif