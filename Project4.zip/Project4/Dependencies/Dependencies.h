#pragma once
/////////////////////////////////////////////////////////////////////////////
// Dependencies.h - To extract all the user headers in same folder          //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * Dependencies provides a class, of the same name, that extracts
 * all header files which located in same folder and also tells the position where the header file located
 *
 *
 * Required Files:
 * ---------------
 * FileSystem.h
 * Dependencies.h
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 05 Mar 2019
 * - first release
 *
 * Planned Additions and Changes:
 * ------------------------------
 * - none yet
 */

#include<iostream>
#include<string>
#include<vector>
#include<map>
#include<regex>
#include "../FileSystem/FileSystem.h"
class Dependencies
{
	public:
		using dependencyTable = std::vector<std::string>;
		using dependencyLineStartsLengthTable = std::vector<std::vector<int>>;
		
		using files = std::vector<std::string>;
		Dependencies();
		~Dependencies();
		void fileDependencies(const std::string& , std::vector<std::string> fileLines);
		void insertIfHeaderExist(int lineNumber,const std::string codeLine, const files& filesList);
		dependencyTable getDependencyHeadersTable();
		dependencyLineStartsLengthTable getDependencyPositionsTable();

	private:
		dependencyTable headerTable_;
		dependencyLineStartsLengthTable positionsTable_;
};

//-------> A construtor to instantiate the object
inline Dependencies::Dependencies()
{
}

//--------> A destructor to Deallocate the memory
inline Dependencies::~Dependencies()
{
}

//--------> Extract all the dependencies for a given file and fileData
inline void Dependencies::fileDependencies(const std::string& filePath,std::vector<std::string> fileLines)
{

	headerTable_.clear();
	
	std::string filedirectory = FileSystem::Path::getPath(filePath);
	files filesinDirectory = FileSystem::Directory::getFiles(filedirectory);
		
	for (size_t i=0;i<fileLines.size();i++)
	{
		// if a line does not contain include then definitely this line did not contain header
		if (fileLines[i].find("include") == std::string::npos)
		{
			continue;
		}
		insertIfHeaderExist(i,fileLines[i], filesinDirectory);
	}
}

// ----------> detects If header present in current line
inline void Dependencies::insertIfHeaderExist(int lineNumber,const std::string codeLine, const files& filesList)
{
	std::string ReplacedCodeLine = codeLine;
	//replacing \r, because to make regex to work properly
	while (ReplacedCodeLine.find("\r") != std::string::npos)
	{
		ReplacedCodeLine.replace(ReplacedCodeLine.find("\r"), 1, "");
	}
	
	for (auto each_file : filesList)
	{	
		std::regex re("(.)*#\\s*include\\s*\""+each_file+"\"(.)*");
		std::smatch regexPositions;
		if (std::regex_match(ReplacedCodeLine, regexPositions, re))
		{
			std::vector<int> positions;
			positions.push_back(lineNumber);// storing the line number where this header file exists
			positions.push_back(regexPositions.position());// storing the index where header file starts in the line
			positions.push_back(regexPositions.position()+regexPositions.length()-1);// storing header end position
			headerTable_.push_back(each_file);
			positionsTable_.push_back(positions);
			return;
		}
	}
	return;
}

//-----------> Return dependencyHeadertable which contain all headers
inline Dependencies::dependencyTable Dependencies::getDependencyHeadersTable()
{
	return headerTable_;
}

//-----------> Return dependencyPositiontable which contain position of the header in a file
inline Dependencies::dependencyLineStartsLengthTable Dependencies::getDependencyPositionsTable()
{
	return positionsTable_;
}
