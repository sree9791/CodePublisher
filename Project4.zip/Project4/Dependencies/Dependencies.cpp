#pragma once
/////////////////////////////////////////////////////////////////////////////
// Dependencies.cpp Contains a Test Stub to extract header files from code  //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2017                             //
// Application: Most Projects, CSE687 - Object Oriented Design             //
// Platform:    Lenovo ideapad 530s, Core amd ryzen5, Windows 10           //
//                                                                         //
// Author:      Sreekar Reddy Sykam, SUID: 367116100, Syracuse University  //
//              (315) 243 7232, ssykam@syr.edu                             //
/////////////////////////////////////////////////////////////////////////////



#include "Dependencies.h"


#ifdef TEST_DEPENDENCIES

//----< A test Stub to extract the header files in code file
int main()
{
	Dependencies de;
	std::vector<std::string> sampleCodeLines = { "#include \"Dependencies.h\"","#include \"Display.h\"","#include \"../Process.h\"" };
	
	de.fileDependencies("Dependencies.cpp",sampleCodeLines);
	std::cout << "  --Dependencies.cpp\n";
	auto dependencyHeaderTable = de.getDependencyHeadersTable();
	auto dependencyPositiontable = de.getDependencyPositionsTable();
	for (size_t i=0;i<dependencyHeaderTable.size();i++)
	{
		std::cout<<"\t+"<< dependencyHeaderTable[i] << " at line " << dependencyPositiontable[i][0] << ", starts at position "<<dependencyPositiontable[i][1] << ", ends at " << dependencyPositiontable[i][2] << std::endl;
	}
	system("pause");
}
#endif // TEST_DEPENDENCIES